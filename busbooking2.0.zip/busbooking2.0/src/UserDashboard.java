import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.HashSet;

public class UserDashboard {
    JFrame f;
    int loggedInUserId; // Evaru login ayyaro teliyadaniki

    public UserDashboard(int userId) {
        this.loggedInUserId = userId; // Login screen nundi ID vastundi

        f = new JFrame("User Dashboard - Book Your Ticket");
        f.setSize(800, 600);
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null); // Center screen

        JLabel title = new JLabel("Welcome to Bus Booking");
        title.setBounds(300, 20, 300, 30);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(Color.BLUE);
        f.add(title);

        // --- 1. BUS TABLE ---
        String[] columns = {"Bus ID", "Bus Name", "Source", "Destination", "Price", "Seats"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(50, 70, 700, 250);
        f.add(sp);

        loadBuses(model); // Database nundi buses load chestundi

        // --- 2. BUTTONS ---
        JButton bookBtn = new JButton("Book Selected Bus");
        bookBtn.setBounds(250, 350, 180, 40);
        bookBtn.setBackground(new Color(50, 205, 50)); // Green color
        bookBtn.setForeground(Color.WHITE);
        f.add(bookBtn);

        // My Bookings Button
        JButton historyBtn = new JButton("My Bookings");
        historyBtn.setBounds(450, 350, 150, 40);
        historyBtn.setBackground(Color.ORANGE);
        historyBtn.setForeground(Color.WHITE);
        f.add(historyBtn);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBounds(650, 20, 100, 30);
        f.add(logoutBtn);

        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.setBounds(50, 20, 100, 30);
        f.add(refreshBtn);

        // --- ACTION LISTENERS ---

        // 1. Book Button Logic
        bookBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if(selectedRow == -1) {
                    JOptionPane.showMessageDialog(f, "Please select a bus row first!");
                    return;
                }
                
                // Get details from selected row
                int busId = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
                String busName = model.getValueAt(selectedRow, 1).toString();
                double price = Double.parseDouble(model.getValueAt(selectedRow, 4).toString());

                // Open Seat Selection
                openSeatSelection(busId, busName, price);
            }
        });

        // 2. My Bookings Button Logic
        historyBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showBookingHistory();
            }
        });

        // 3. Logout
        logoutBtn.addActionListener(e -> {
            f.dispose();
            LoginScreen.main(null);
        });

        // 4. Refresh Table
        refreshBtn.addActionListener(e -> {
            model.setRowCount(0); // Clear table
            loadBuses(model); // Reload
        });

        f.setVisible(true);
    }

    // --- LOAD BUSES FROM DB ---
    private void loadBuses(DefaultTableModel model) {
        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM buses");
            while(rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("bus_id"),
                    rs.getString("bus_name"),
                    rs.getString("source"),
                    rs.getString("destination"),
                    rs.getDouble("price"),
                    rs.getInt("seats")
                });
            }
        } catch(Exception e) { e.printStackTrace(); }
    }

    // --- SHOW BOOKING HISTORY ---
    private void showBookingHistory() {
        JFrame hFrame = new JFrame("My Bookings History");
        hFrame.setSize(600, 400);
        hFrame.setLocationRelativeTo(f);

        String[] cols = {"Ticket ID", "Bus Name", "From", "To", "Seat No", "Date"};
        DefaultTableModel hModel = new DefaultTableModel(cols, 0);
        JTable hTable = new JTable(hModel);
        JScrollPane hSp = new JScrollPane(hTable);
        hFrame.add(hSp);

        try {
            Connection con = DBConnection.getConnection();
            // SQL JOIN Query
            String q = "SELECT b.booking_id, bus.bus_name, bus.source, bus.destination, b.seat_no, b.booking_date " +
                       "FROM bookings b " +
                       "JOIN buses bus ON b.bus_id = bus.bus_id " +
                       "WHERE b.user_id = ?";
            
            PreparedStatement pst = con.prepareStatement(q);
            pst.setInt(1, loggedInUserId);
            ResultSet rs = pst.executeQuery();

            while(rs.next()) {
                hModel.addRow(new Object[]{
                    rs.getInt("booking_id"),
                    rs.getString("bus_name"),
                    rs.getString("source"),
                    rs.getString("destination"),
                    rs.getInt("seat_no"),
                    rs.getDate("booking_date")
                });
            }
        } catch(Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(hFrame, "Error fetching history!");
        }

        hFrame.setVisible(true);
    }

    // --- SEAT SELECTION WINDOW (Updated for Payment) ---
    private void openSeatSelection(int busId, String busName, double price) {
        JFrame seatFrame = new JFrame("Select Seat - " + busName);
        seatFrame.setSize(500, 600);
        seatFrame.setLocationRelativeTo(f);

        JPanel panel = new JPanel(new GridLayout(10, 5, 10, 10)); 
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        HashSet<Integer> bookedSeats = getBookedSeats(busId);

        for (int i = 1; i <= 40; i++) {
            int seatNo = i;
            JButton seatBtn = new JButton("S" + i);
            
            if (bookedSeats.contains(seatNo)) {
                seatBtn.setBackground(Color.RED);
                seatBtn.setForeground(Color.WHITE);
                seatBtn.setEnabled(false); 
            } else {
                seatBtn.setBackground(Color.GREEN);
            }

            // --- THIS PART IS UPDATED FOR PAYMENT ---
            seatBtn.addActionListener(e -> {
                int choice = JOptionPane.showConfirmDialog(seatFrame, 
                    "Seat " + seatNo + " costs Rs." + price + ".\nProceed to Payment?", 
                    "Confirm Booking", JOptionPane.YES_NO_OPTION);
                
                if (choice == JOptionPane.YES_OPTION) {
                    // Close Seat Window
                    seatFrame.dispose(); 
                    
                    // OPEN PAYMENT SCREEN
                    
                    new PaymentScreen(busId, seatNo, loggedInUserId, price); 
                }
            });
            // ----------------------------------------

            panel.add(seatBtn);

            // GAP LOGIC (2 seats - Gap - 2 seats)
            if (i % 2 == 0 && i % 4 != 0) {
                JLabel gap = new JLabel(""); 
                panel.add(gap);
            }
        }

        seatFrame.add(panel);
        seatFrame.setVisible(true);
    }

    private HashSet<Integer> getBookedSeats(int busId) {
        HashSet<Integer> booked = new HashSet<>();
        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement("SELECT seat_no FROM bookings WHERE bus_id=?");
            pst.setInt(1, busId);
            ResultSet rs = pst.executeQuery();
            while(rs.next()) booked.add(rs.getInt("seat_no"));
        } catch(Exception e) { e.printStackTrace(); }
        return booked;
    }
}