import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminDashboard {
    JFrame f;

    AdminDashboard() {
        f = new JFrame("Admin Dashboard - Manage Buses");
        f.setSize(700, 500); // Size koncham pencha
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);

        // Heading
        JLabel title = new JLabel("Manage Buses");
        title.setBounds(250, 20, 200, 30);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        f.add(title);

        // --- INPUT FIELDS ---
        JLabel l1 = new JLabel("Bus Name:");
        l1.setBounds(50, 80, 100, 30);
        f.add(l1);
        JTextField busNameField = new JTextField();
        busNameField.setBounds(150, 80, 200, 30);
        f.add(busNameField);

        JLabel l2 = new JLabel("Source:");
        l2.setBounds(50, 130, 100, 30);
        f.add(l2);
        JTextField sourceField = new JTextField();
        sourceField.setBounds(150, 130, 200, 30);
        f.add(sourceField);

        JLabel l3 = new JLabel("Destination:");
        l3.setBounds(50, 180, 100, 30);
        f.add(l3);
        JTextField destField = new JTextField();
        destField.setBounds(150, 180, 200, 30);
        f.add(destField);

        JLabel l4 = new JLabel("Price:");
        l4.setBounds(50, 230, 100, 30);
        f.add(l4);
        JTextField priceField = new JTextField();
        priceField.setBounds(150, 230, 200, 30);
        f.add(priceField);

        JLabel l5 = new JLabel("Total Seats:");
        l5.setBounds(50, 280, 100, 30);
        f.add(l5);
        JTextField seatsField = new JTextField("40");
        seatsField.setBounds(150, 280, 200, 30);
        f.add(seatsField);

        // --- BUTTONS ---
        JButton addBtn = new JButton("Add Bus");
        addBtn.setBounds(150, 340, 100, 35);
        addBtn.setBackground(new Color(50, 205, 50)); // Green
        addBtn.setForeground(Color.WHITE);
        f.add(addBtn);

        JButton clearBtn = new JButton("Clear");
        clearBtn.setBounds(260, 340, 90, 35);
        f.add(clearBtn);

        // --- NEW DELETE BUTTON ---
        JButton deleteBtn = new JButton("Delete Bus");
        deleteBtn.setBounds(400, 340, 120, 35);
        deleteBtn.setBackground(Color.RED);
        deleteBtn.setForeground(Color.WHITE);
        f.add(deleteBtn);

        // --- VIEW BUSES BUTTON (Optional: To see IDs) ---
        JButton viewBtn = new JButton("View All Buses");
        viewBtn.setBounds(400, 80, 150, 30);
        f.add(viewBtn);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBounds(550, 20, 100, 30);
        f.add(logoutBtn);

        // --- ADD BUS LOGIC ---
        addBtn.addActionListener(e -> {
            String bName = busNameField.getText();
            String src = sourceField.getText();
            String dest = destField.getText();
            String priceStr = priceField.getText();
            String seatsStr = seatsField.getText();

            if(bName.isEmpty() || src.isEmpty() || dest.isEmpty() || priceStr.isEmpty()) {
                JOptionPane.showMessageDialog(f, "Please fill all details!");
                return;
            }

            try {
                Connection con = DBConnection.getConnection();
                String query = "INSERT INTO buses (bus_name, source, destination, price, seats) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement pst = con.prepareStatement(query);
                pst.setString(1, bName);
                pst.setString(2, src);
                pst.setString(3, dest);
                pst.setDouble(4, Double.parseDouble(priceStr));
                pst.setInt(5, Integer.parseInt(seatsStr));
                
                int k = pst.executeUpdate();
                if(k > 0) {
                    JOptionPane.showMessageDialog(f, "Bus Added Successfully!");
                    busNameField.setText(""); sourceField.setText("");
                    destField.setText(""); priceField.setText("");
                }
            } catch (Exception ex) { ex.printStackTrace(); }
        });

        // --- DELETE BUS LOGIC (NEW) ---
        deleteBtn.addActionListener(e -> {
            // Popup aduguthundi Bus ID kosam
            String busIdStr = JOptionPane.showInputDialog(f, "Enter BUS ID to Delete:");
            
            if(busIdStr != null && !busIdStr.isEmpty()) {
                int busId = Integer.parseInt(busIdStr);
                try {
                    Connection con = DBConnection.getConnection();
                    
                    // Step 1: First Bookings delete cheyali (Safety)
                    PreparedStatement pst1 = con.prepareStatement("DELETE FROM bookings WHERE bus_id = ?");
                    pst1.setInt(1, busId);
                    pst1.executeUpdate();

                    // Step 2: Tarvatha Bus delete cheyali
                    PreparedStatement pst2 = con.prepareStatement("DELETE FROM buses WHERE bus_id = ?");
                    pst2.setInt(1, busId);
                    
                    int k = pst2.executeUpdate();
                    if(k > 0) {
                        JOptionPane.showMessageDialog(f, "Bus Deleted Successfully!");
                    } else {
                        JOptionPane.showMessageDialog(f, "Bus ID Not Found!");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(f, "Error Deleting Bus!");
                }
            }
        });

        // --- VIEW BUSES LOGIC (To see IDs) ---
        viewBtn.addActionListener(e -> {
            JFrame tblFrame = new JFrame("All Buses List");
            tblFrame.setSize(500, 400);
            tblFrame.setLocationRelativeTo(f);
            
            String[] cols = {"ID", "Name", "From", "To", "Price"};
            DefaultTableModel model = new DefaultTableModel(cols, 0);
            JTable table = new JTable(model);
            tblFrame.add(new JScrollPane(table));

            try {
                Connection con = DBConnection.getConnection();
                ResultSet rs = con.createStatement().executeQuery("SELECT * FROM buses");
                while(rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("bus_id"), rs.getString("bus_name"),
                        rs.getString("source"), rs.getString("destination"),
                        rs.getDouble("price")
                    });
                }
            } catch(Exception ex) { ex.printStackTrace(); }
            
            tblFrame.setVisible(true);
        });

        // Logout
        logoutBtn.addActionListener(e -> {
            f.dispose();
            LoginScreen.main(null);
        });

        clearBtn.addActionListener(e -> {
            busNameField.setText(""); sourceField.setText("");
            destField.setText(""); priceField.setText("");
        });

        f.setVisible(true);
    }

    public static void main(String[] args) {
        new AdminDashboard();
    }
}