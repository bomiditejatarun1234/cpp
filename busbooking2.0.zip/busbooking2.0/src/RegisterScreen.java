import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class RegisterScreen {
    JFrame f;

    RegisterScreen() {
        f = new JFrame("Bus Booking Registration");
        f.setSize(400, 400);
        f.setLayout(null);

        JLabel l1 = new JLabel("Username:");
        l1.setBounds(50, 50, 100, 30);
        f.add(l1);

        JTextField userField = new JTextField();
        userField.setBounds(150, 50, 150, 30);
        f.add(userField);

        JLabel l2 = new JLabel("Password:");
        l2.setBounds(50, 100, 100, 30);
        f.add(l2);

        JPasswordField passField = new JPasswordField();
        passField.setBounds(150, 100, 150, 30);
        f.add(passField);

        JLabel l3 = new JLabel("Phone:");
        l3.setBounds(50, 150, 100, 30);
        f.add(l3);

        JTextField phoneField = new JTextField();
        phoneField.setBounds(150, 150, 150, 30);
        f.add(phoneField);

        JLabel l4 = new JLabel("Select Role:");
        l4.setBounds(50, 200, 100, 30);
        f.add(l4);

        // --- IKKADA NEEKU ADMIN/USER OPTION VASTUNDI ---
        String[] roles = { "User", "Admin" };
        JComboBox<String> roleBox = new JComboBox<>(roles);
        roleBox.setBounds(150, 200, 150, 30);
        f.add(roleBox);

        JButton regBtn = new JButton("Register");
        regBtn.setBounds(150, 250, 100, 30);
        f.add(regBtn);

        JLabel msg = new JLabel("");
        msg.setBounds(50, 300, 300, 30);
        f.add(msg);

        regBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String u = userField.getText();
                String p = new String(passField.getPassword());
                String ph = phoneField.getText();
                String r = roleBox.getSelectedItem().toString().toLowerCase(); // 'user' or 'admin'

                try {
                    Connection con = DBConnection.getConnection();
                    if(con == null) {
                        msg.setText("Database Connection Failed!");
                        return;
                    }
                    String q = "INSERT INTO users (username, password, phone, role) VALUES (?, ?, ?, ?)";
                    PreparedStatement pst = con.prepareStatement(q);
                    pst.setString(1, u);
                    pst.setString(2, p);
                    pst.setString(3, ph);
                    pst.setString(4, r);
                    pst.executeUpdate();
                    
                    JOptionPane.showMessageDialog(f, "Registration Successful! Please Login.");
                    f.dispose(); // Close register window
                } catch (Exception ex) {
                    ex.printStackTrace();
                    msg.setText("Error: " + ex.getMessage());
                }
            }
        });

        f.setVisible(true);
    }
}