import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Kotha Database Name: bus_final_db
            // IMPORTANT: "YOUR_PASSWORD" daggara nee nijamaina password pettu
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bus_final_db", "root", "Bharath@0917");
        } catch (Exception e) {
            System.out.println("Connection Error: " + e);
        }
        return con;
    }
}