import java.sql.*;
import java.util.Scanner;

public class BusDAO {
    static Scanner sc = new Scanner(System.in);

    // --- ADMIN: ADD BUS ---
    public static void addBus() {
        System.out.print("Enter Bus Name: ");
        String name = sc.next();
        System.out.print("Source: ");
        String src = sc.next();
        System.out.print("Destination: ");
        String dest = sc.next();
        System.out.print("Price: ");
        double price = sc.nextDouble();

        try {
            Connection con = DBConnection.getConnection();
            String q = "INSERT INTO buses (bus_name, source, destination, price) VALUES (?, ?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(q);
            pst.setString(1, name);
            pst.setString(2, src);
            pst.setString(3, dest);
            pst.setDouble(4, price);
            pst.executeUpdate();
            System.out.println("Bus Added Successfully!");
        } catch (Exception e) { e.printStackTrace(); }
    }

    // --- ADMIN: DELETE BUS ---
    public static void deleteBus() {
        System.out.print("Enter Bus ID to delete: ");
        int id = sc.nextInt();
        try {
            Connection con = DBConnection.getConnection();
            con.createStatement().executeUpdate("DELETE FROM buses WHERE bus_id=" + id);
            System.out.println("Bus Deleted.");
        } catch (Exception e) { e.printStackTrace(); }
    }

    // --- USER: VIEW AND BOOK ---
    public static void viewAndBook(int userId) {
        try {
            Connection con = DBConnection.getConnection();
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM buses");
            
            System.out.println("\nAvailable Buses:");
            System.out.println("ID | Name | Route | Price");
            while(rs.next()) {
                System.out.println(rs.getInt("bus_id") + " | " + rs.getString("bus_name") + " | " + 
                                   rs.getString("source") + "-" + rs.getString("destination") + " | " + rs.getDouble("price"));
            }

            System.out.print("\nEnter Bus ID to Book: ");
            int busId = sc.nextInt();
            
            displaySeats(busId); // Seat map chupistundi

            System.out.print("\nEnter Seat Number to Book: ");
            int seatNo = sc.nextInt();
            
            // Checking if seat is already booked
            String checkQ = "SELECT * FROM bookings WHERE bus_id=? AND seat_no=?";
            PreparedStatement checkPst = con.prepareStatement(checkQ);
            checkPst.setInt(1, busId);
            checkPst.setInt(2, seatNo);
            ResultSet checkRs = checkPst.executeQuery();

            if(checkRs.next()) {
                System.out.println("Sorry! This seat is already booked.");
            } else {
                String bookQ = "INSERT INTO bookings (user_id, bus_id, seat_no, booking_date) VALUES (?, ?, ?, NOW())";
                PreparedStatement pst = con.prepareStatement(bookQ);
                pst.setInt(1, userId);
                pst.setInt(2, busId);
                pst.setInt(3, seatNo);
                pst.executeUpdate();
                System.out.println("Success! Booking Confirmed for Seat " + seatNo);
            }

        } catch (Exception e) { 
            e.printStackTrace();
        }
    }

    // --- SEATING ARRANGEMENT LOGIC ---
    public static void displaySeats(int busId) {
        System.out.println("\n--- SEAT LAYOUT ---");
        try {
            Connection con = DBConnection.getConnection();
            String q = "SELECT seat_no FROM bookings WHERE bus_id = ?";
            PreparedStatement pst = con.prepareStatement(q);
            pst.setInt(1, busId);
            ResultSet rs = pst.executeQuery();
            
            // Book aina seats ni list lo pettukuntunnam
            java.util.HashSet<Integer> bookedSeats = new java.util.HashSet<>();
            while(rs.next()) {
                bookedSeats.add(rs.getInt("seat_no"));
            }

            int totalSeats = 20; 
            for (int i = 1; i <= totalSeats; i++) {
                if (bookedSeats.contains(i)) {
                    System.out.print("[X] "); // Book aithe X
                } else {
                    System.out.print("[" + i + "] "); // Khali unte Number
                }
                
                // Gap logic
                if (i % 2 == 0) System.out.print("    "); 
                if (i % 4 == 0) System.out.println();
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}