import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class LoginScreen {

    public static void main(String[] args) {
        // 1. Frame Setup
        JFrame f = new JFrame("Bus Booking Login");
        f.setSize(400, 350);
        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null); // Window center lo open avthundi

        // 2. Username Field
        JLabel l1 = new JLabel("Username:");
        l1.setBounds(50, 50, 100, 30);
        f.add(l1);

        JTextField userField = new JTextField();
        userField.setBounds(150, 50, 150, 30);
        f.add(userField);

        // 3. Password Field
        JLabel l2 = new JLabel("Password:");
        l2.setBounds(50, 100, 100, 30);
        f.add(l2);

        JPasswordField passField = new JPasswordField();
        passField.setBounds(150, 100, 150, 30);
        f.add(passField);

        // 4. Buttons
        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(50, 160, 100, 30);
        f.add(loginBtn);

        JButton registerBtn = new JButton("Register");
        registerBtn.setBounds(180, 160, 120, 30);
        f.add(registerBtn);

        JLabel message = new JLabel("");
        message.setBounds(50, 220, 300, 30);
        f.add(message);

        // --- LOGIN LOGIC ---
        loginBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText();
                String password = new String(passField.getPassword());

                try {
                    Connection con = DBConnection.getConnection();
                    if (con == null) {
                        message.setText("Database Connection Error!");
                        return;
                    }

                    String query = "SELECT * FROM users WHERE username=? AND password=?";
                    PreparedStatement pst = con.prepareStatement(query);
                    pst.setString(1, username);
                    pst.setString(2, password);
                    ResultSet rs = pst.executeQuery();

                    if (rs.next()) {
                        String role = rs.getString("role");
                        int userId = rs.getInt("id"); // User ID safe side theeskuntunnam

                        // Check Role
                        if (role.equalsIgnoreCase("admin")) {
                            JOptionPane.showMessageDialog(f, "Welcome Admin!");
                            f.dispose(); // Close Login Window
                            new AdminDashboard(); // Open Admin Dashboard
                        } else {
    JOptionPane.showMessageDialog(f, "Welcome User!");
    f.dispose(); // Close Login
    new UserDashboard(userId); // Open User Dashboard & Pass User ID
}
                    } else {
                        JOptionPane.showMessageDialog(f, "Invalid Username or Password!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    message.setText("Database Error!");
                }
            }
        });

        // --- REGISTER BUTTON LOGIC ---
        registerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new RegisterScreen(); // Open Register Page
            }
        });

        f.setVisible(true);
    }
}