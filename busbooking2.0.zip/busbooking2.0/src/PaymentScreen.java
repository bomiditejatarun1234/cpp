import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class PaymentScreen {
    JFrame f;
    int busId, seatNo, userId;
    double amount;
    JRadioButton r1, r2; // Card or UPI kosam

    public PaymentScreen(int busId, int seatNo, int userId, double amount) {
        this.busId = busId;
        this.seatNo = seatNo;
        this.userId = userId;
        this.amount = amount;

        f = new JFrame("Payment Gateway");
        f.setSize(400, 450);
        f.setLayout(null);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel title = new JLabel("Secure Payment");
        title.setBounds(120, 20, 200, 30);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        f.add(title);

        JLabel amtLabel = new JLabel("Total Amount: Rs. " + amount);
        amtLabel.setBounds(50, 60, 300, 30);
        amtLabel.setFont(new Font("Arial", Font.BOLD, 14));
        amtLabel.setForeground(Color.BLUE);
        f.add(amtLabel);

        JLabel modeLabel = new JLabel("Select Payment Mode:");
        modeLabel.setBounds(50, 100, 150, 30);
        f.add(modeLabel);

        r1 = new JRadioButton("Credit/Debit Card");
        r2 = new JRadioButton("UPI");
        r1.setBounds(50, 130, 150, 30);
        r2.setBounds(200, 130, 100, 30);
        ButtonGroup bg = new ButtonGroup();
        bg.add(r1); bg.add(r2);
        r1.setSelected(true); 
        f.add(r1); f.add(r2);

        JLabel cardLabel = new JLabel("Card/UPI ID:");
        cardLabel.setBounds(50, 170, 100, 30);
        f.add(cardLabel);
        JTextField cardField = new JTextField();
        cardField.setBounds(150, 170, 200, 30);
        f.add(cardField);

        JLabel cvvLabel = new JLabel("CVV/PIN:");
        cvvLabel.setBounds(50, 210, 80, 30);
        f.add(cvvLabel);
        JPasswordField cvvField = new JPasswordField();
        cvvField.setBounds(150, 210, 80, 30);
        f.add(cvvField);

        JButton payBtn = new JButton("Pay Now");
        payBtn.setBounds(120, 270, 150, 40);
        payBtn.setBackground(new Color(34, 139, 34)); 
        payBtn.setForeground(Color.WHITE);
        f.add(payBtn);

        // PAY BUTTON LOGIC
        payBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if(cardField.getText().isEmpty() || new String(cvvField.getPassword()).isEmpty()) {
                    JOptionPane.showMessageDialog(f, "Please enter payment details!");
                    return;
                }

                JOptionPane.showMessageDialog(f, "Payment Processing...");
                
                // Which mode selected?
                String paymentMode = r1.isSelected() ? "Card" : "UPI";
                
                processPaymentAndBook(paymentMode);
            }
        });

        f.setVisible(true);
    }

    // --- PAYMENT & BOOKING DATABASE LOGIC ---
    private void processPaymentAndBook(String paymentMode) {
        try {
            Connection con = DBConnection.getConnection();
            
            // 1. Check if seat is still available
            PreparedStatement check = con.prepareStatement("SELECT * FROM bookings WHERE bus_id=? AND seat_no=?");
            check.setInt(1, busId);
            check.setInt(2, seatNo);
            if(check.executeQuery().next()) {
                JOptionPane.showMessageDialog(f, "Transaction Failed! Seat just got booked by someone else.");
                return;
            }

            // 2. Insert into PAYMENTS table
            String payQuery = "INSERT INTO payments (user_id, bus_id, amount, payment_mode, payment_status) VALUES (?, ?, ?, ?, 'Success')";
            PreparedStatement pstPay = con.prepareStatement(payQuery);
            pstPay.setInt(1, userId);
            pstPay.setInt(2, busId);
            pstPay.setDouble(3, amount);
            pstPay.setString(4, paymentMode);
            pstPay.executeUpdate();

            // 3. Insert into BOOKINGS table
            String bookQuery = "INSERT INTO bookings (user_id, bus_id, seat_no, booking_date) VALUES (?, ?, ?, NOW())";
            PreparedStatement pstBook = con.prepareStatement(bookQuery);
            pstBook.setInt(1, userId);
            pstBook.setInt(2, busId);
            pstBook.setInt(3, seatNo);
            pstBook.executeUpdate();

            JOptionPane.showMessageDialog(f, "Payment Successful! \nTicket Booked for Seat: " + seatNo);
            f.dispose(); 
            
        } catch(Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(f, "Payment Failed due to System Error.");
        }
    }
}