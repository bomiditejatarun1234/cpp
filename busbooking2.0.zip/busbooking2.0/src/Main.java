import java.util.Scanner;
import java.sql.*;

public class Main {
    static Scanner sc = new Scanner(System.in);
    
    public static void main(String[] args) {
        while(true) {
            System.out.println("\n--- BUS BOOKING SYSTEM ---");
            System.out.println("1. Register (First Time Users Click Here)");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Enter Choice: ");
            int choice = sc.nextInt();

            if(choice == 1) register();
            else if(choice == 2) login();
            else break;
        }
    }

    // --- UPDATED REGISTRATION METHOD ---
    public static void register() {
        System.out.println("\n--- REGISTRATION ---");
        System.out.print("Enter Username: ");
        String user = sc.next();
        System.out.print("Enter Password: ");
        String pass = sc.next();
        System.out.print("Enter Phone: ");
        String phone = sc.next();
        
        // Ikkada user ni adugutunnam Admin ah User ah ani
        System.out.print("Enter Role (admin/user): ");
        String role = sc.next().toLowerCase(); // chinna letters lo convert chestundi

        // Validation: user enter chesindi correct role eh na?
        if(!role.equals("admin") && !role.equals("user")) {
            System.out.println("Invalid Role! Please enter 'admin' or 'user'.");
            return;
        }

        try {
            Connection con = DBConnection.getConnection();
            // Role ni kuda parameter (?) laaga pass chestunnam
            String query = "INSERT INTO users (username, password, phone, role) VALUES (?, ?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, user);
            pst.setString(2, pass);
            pst.setString(3, phone);
            pst.setString(4, role); // User ichina role save avtundi
            
            int rows = pst.executeUpdate();
            if(rows > 0) {
                System.out.println("Registration Successful! Now please Login.");
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            System.out.println("Username already exists! Try another one.");
        } catch (Exception e) { 
            e.printStackTrace(); 
        }
    }

    public static void login() {
        System.out.println("\n--- LOGIN ---");
        System.out.print("Username: ");
        String user = sc.next();
        System.out.print("Password: ");
        String pass = sc.next();

        try {
            Connection con = DBConnection.getConnection();
            String query = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, user);
            pst.setString(2, pass);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String role = rs.getString("role");
                int userId = rs.getInt("id");
                System.out.println("\nLogin Successful! Welcome " + user);
                
                // Role ni batti Dashboard open avtundi
                if (role.equals("admin")) {
                    adminDashboard();
                } else {
                    userDashboard(userId);
                }
            } else {
                System.out.println("Invalid Credentials! Please Register first if you haven't.");
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    // --- DASHBOARDS (Paatha code same) ---

    public static void adminDashboard() {
        while(true) {
            System.out.println("\n--- ADMIN DASHBOARD ---");
            System.out.println("1. Add Bus");
            System.out.println("2. Delete Bus");
            System.out.println("3. Logout");
            System.out.print("Choose: ");
            int ch = sc.nextInt();
            if(ch == 1) BusDAO.addBus();
            else if(ch == 2) BusDAO.deleteBus();
            else return;
        }
    }

    public static void userDashboard(int userId) {
        while(true) {
            System.out.println("\n--- USER DASHBOARD ---");
            System.out.println("1. View Buses & Book");
            System.out.println("2. Logout");
            System.out.print("Choose: ");
            int ch = sc.nextInt();
            if(ch == 1) BusDAO.viewAndBook(userId);
            else return;
        }
    }
}